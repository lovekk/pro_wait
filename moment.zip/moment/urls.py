# -*- coding: utf-8 -*-
# @Time    : 2018/12/10 16:17
# @Author  : super_zhangkun
# @Email   : 3476899885@qq.com
# @File    : urls.py
# @Software: PyCharm

from django.urls import path
from moment import views
from moment.views import AddView, TagView, IndexView, ReportView,MomentDetailView,AddCommentView,MomentGoodView,CommentGoodView,ReplyCommentDetailView,ReplyCommentView


urlpatterns = [
    path('moment_list/',views.moment_list,name='moment_list'),
    path('moment_add/',views.moment_add,name='moment_add'),

    path('index/', IndexView.as_view(), name='index'),
    path('add/', AddView.as_view(), name='add'),
    path('tag/', TagView.as_view(), name='tag'),
    path('report/', ReportView.as_view(), name='report'),
    path('moment_detail/',MomentDetailView.as_view(),name='moment_detail'),

    path('add_comment/',AddCommentView.as_view(),name='add_comment'),
    path('moment_good/',MomentGoodView.as_view(),name='moment_good'),
    path('comment_good/',CommentGoodView.as_view(),name='comment_good'),
    path('add_reply_comment/',ReplyCommentView.as_view(),name='add_reply_comment'),
    path('reply_comment_detail/',ReplyCommentDetailView.as_view(),name='reply_comment_detail'),

]
