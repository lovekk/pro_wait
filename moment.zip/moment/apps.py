from django.apps import AppConfig


class MomentConfig(AppConfig):
    name = 'moment'
    verbose_name = '发现·动态'
