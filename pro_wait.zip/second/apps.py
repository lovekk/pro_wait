from django.apps import AppConfig


class SecondConfig(AppConfig):
    name = 'second'
    verbose_name = '二手市场'
