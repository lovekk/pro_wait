

from django.urls import path
from second import views
from second.views import IndexView, AddView

urlpatterns = [
    path('second_list/',views.second_list,name='second_list'),
    path('second_add/',views.second_add,name='second_add'),

    path('index/', IndexView.as_view(), name='index'),
    path('add/', AddView.as_view(), name='add'),
]