
__author__ = 'super'
__date__ = '2018/12/4 15:54'

from django.urls import path
from notice import views

urlpatterns = [
    path('notice_list/',views.notice_list,name='notice_list'),
    path('notice_detail/',views.notice_detail,name='notice_detail'),
]