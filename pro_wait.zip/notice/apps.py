from django.apps import AppConfig


class NoticeConfig(AppConfig):
    name = 'notice'
    verbose_name = '校园公告'
