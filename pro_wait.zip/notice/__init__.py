
default_app_config = 'notice.apps.NoticeConfig'