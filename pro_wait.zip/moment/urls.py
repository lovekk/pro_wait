# -*- coding: utf-8 -*-
# @Time    : 2018/12/10 16:17
# @Author  : super_zhangkun
# @Email   : 3476899885@qq.com
# @File    : urls.py
# @Software: PyCharm

from django.urls import path
from moment import views
from moment.views import AddView, TagView, IndexView, ReportView

urlpatterns = [
    path('moment_list/',views.moment_list,name='moment_list'),
    path('moment_add/',views.moment_add,name='moment_add'),

    path('index/', IndexView.as_view(), name='index'),
    path('add/', AddView.as_view(), name='add'),
    path('tag/', TagView.as_view(), name='tag'),
    path('report/', ReportView.as_view(), name='report'),
]
