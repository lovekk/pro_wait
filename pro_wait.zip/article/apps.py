from django.apps import AppConfig


class ArticleConfig(AppConfig):
    name = 'article'
    verbose_name = '校园文章'
