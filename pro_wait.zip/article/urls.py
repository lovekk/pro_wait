
from django.urls import path
from article import views

urlpatterns = [
    path('article_list/',views.article_list,name='article_list'),
    path('article_detail/', views.article_detail, name='article_detail'),
    path('comment/', views.add_comment, name='comment'),
]