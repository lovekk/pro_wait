
default_app_config = 'activity.apps.ActivityConfig'