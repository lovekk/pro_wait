
from django.apps import AppConfig


class ActivityConfig(AppConfig):
    name = 'activity'
    verbose_name = '校园活动'