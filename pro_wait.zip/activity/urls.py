

from django.urls import path
from activity import views

urlpatterns = [
    path('activity_list/',views.activity_list,name='activity_list'),
    path('activity_detail/',views.activity_detail,name='activity_detail'),
    path('comment/',views.add_comment,name='comment'),
]