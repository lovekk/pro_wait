"""wait URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('tinymce/', include('tinymce.urls')),

    # http://ip/user/
    path('user/', include('user.urls')),  # 用户模块

    path('homepage/', include('homepage.urls')),  # 首页模块
    path('activity/',include('activity.urls')),  # 校园活动
    path('article/',include('article.urls')),  # 校园文章
    path('culture/',include('culture.urls')),  # 校园文化
    path('notice/',include('notice.urls')),  # 校园公告
    path('lose/',include('lose.urls')),  # 失物招领
    path('second/',include('second.urls')),  # 二手市场

    path('moment/',include('moment.urls')),  # 发现 时刻


] + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
