from django.apps import AppConfig


class UserConfig(AppConfig):
    name = 'user'
    verbose_name = '等你下课·vip用户'
