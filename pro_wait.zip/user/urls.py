
from django.urls import path
from user import views

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # http://ip/user/
    path('index/', views.index, name='index'), # 用户首页 测试
    path('json/', views.test_json, name='json'), # json 测试

    path('login/', views.login, name='login'),  # 登录

    path('register/', views.register, name='register'),  # 注册手机
    path('registermsg/', views.register_msg, name='registermsg'),  # 注册用户信息
    path('school/', views.school_list, name='school'),  # 学校列表
    
    
    
] + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
