

default_app_config = 'culture.apps.CultureConfig'