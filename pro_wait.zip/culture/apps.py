from django.apps import AppConfig


class CultureConfig(AppConfig):
    name = 'culture'
    verbose_name = '校园文化'
