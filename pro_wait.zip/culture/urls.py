# -*- coding: utf-8 -*-
__author__ = 'super'
__date__ = '2018/12/4 15:53'

from django.urls import path
from culture import views

urlpatterns = [
    path('culture/',views.culture_content,name='culture'),
    path('comment/',views.add_comment,name='comment'),
]