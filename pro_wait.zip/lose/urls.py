

from django.urls import path
from lose import views


urlpatterns = [
    path('lose_list/',views.lose_list,name='lose_list'),
    path('lose_add/',views.lose_add,name='lose_add'),


]