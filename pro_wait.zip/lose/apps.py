from django.apps import AppConfig


class LoseConfig(AppConfig):
    name = 'lose'
    verbose_name = '失物招领'
