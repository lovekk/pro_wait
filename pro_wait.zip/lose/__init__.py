

default_app_config = 'lose.apps.LoseConfig'